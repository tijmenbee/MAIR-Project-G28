- (Ideally, create virtual environment for this project)
- Install dependencies: `pip install -r requirements.txt`
- Always run python from the root directory of this project.
- To run evaluation metrics stuff, run `classifiers/eval.py`
- To run the dialogue system, run `dialog_system/main.py`
- You can provide config options as CLI options - they imitate what you can change during
 the conversation also. They're described in the report.

